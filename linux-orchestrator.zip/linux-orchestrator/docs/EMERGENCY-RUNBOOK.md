# 🚨 EMERGENCY-RUNBOOK.md - Procedury Awaryjne

> **INSTRUKCJE NA WYPADEK AWARII**
> 
> Przeczytaj CAŁĄ procedurę przed wykonaniem.
> Dokumentuj każdy krok w logu.

---

## ⚡ QUICK REFERENCE

| Problem | Procedura | Szacowany czas |
|---------|-----------|----------------|
| Serwer nie odpowiada | [PROC-001](#proc-001-serwer-nie-odpowiada) | 5-15 min |
| Dysk pełny | [PROC-002](#proc-002-dysk-pełny) | 5-10 min |
| Kontener nie startuje | [PROC-003](#proc-003-kontener-nie-startuje) | 10-30 min |
| Atak DDoS/brute-force | [PROC-004](#proc-004-atak-ddosbrute-force) | 5-15 min |
| Wyciek danych | [PROC-005](#proc-005-wyciek-danych--breach) | NATYCHMIAST |
| Baza danych niedostępna | [PROC-006](#proc-006-baza-danych-niedostępna) | 10-30 min |
| SSL/Certyfikat wygasł | [PROC-007](#proc-007-certyfikat-ssl-wygasł) | 5-10 min |
| Out of Memory | [PROC-008](#proc-008-out-of-memory) | 5-15 min |

---

## PROC-001: Serwer nie odpowiada

### Symptomy:
- Brak odpowiedzi na ping
- SSH timeout
- Usługi niedostępne

### Diagnoza:
```bash
# Z zewnętrznej maszyny
ping -c 5 [IP_SERWERA]
ssh -v admin@[IP_SERWERA]
curl -I https://[DOMENA] --connect-timeout 10

# Sprawdź status u providera (OVH/Hetzner/AWS console)
```

### Rozwiązanie:

**Poziom 1: Soft reboot (jeśli masz dostęp do panelu)**
1. Zaloguj się do panelu providera
2. Wykonaj soft reboot
3. Czekaj 2-3 minuty
4. Sprawdź połączenie

**Poziom 2: Hard reboot**
1. W panelu providera: Hard reboot
2. Czekaj 5 minut
3. Sprawdź połączenie
4. Jeśli działa → sprawdź logi: `journalctl -b -1` (poprzedni boot)

**Poziom 3: Rescue mode**
1. Uruchom w rescue mode (panel providera)
2. Zamontuj dyski
3. Sprawdź `/var/log/` po przyczyny
4. Napraw i restartuj

### Po naprawie:
```bash
# Sprawdź stan usług
docker ps -a
systemctl --failed
df -h
free -h

# Dokumentuj
echo "[$(date)] PROC-001 executed - [OPIS]" >> /var/log/incidents.log
```

---

## PROC-002: Dysk pełny

### Symptomy:
- `No space left on device`
- Kontenery crashują
- Logi nie zapisują się

### Diagnoza:
```bash
# Sprawdź użycie
df -h
du -sh /* 2>/dev/null | sort -h | tail -20

# Docker specific
docker system df
docker system df -v
```

### Rozwiązanie:

**Krok 1: Szybkie zwolnienie miejsca**
```bash
# Docker cleanup (BEZPIECZNE)
docker system prune -f
docker image prune -a -f --filter "until=168h"  # obrazy starsze niż 7 dni

# Logi kontenerów (OSTROŻNIE - tracisz historię!)
truncate -s 0 /var/lib/docker/containers/*/*-json.log

# Stare logi systemowe
journalctl --vacuum-time=3d
```

**Krok 2: Identyfikacja winowajcy**
```bash
# Największe pliki
find / -type f -size +100M -exec ls -lh {} \; 2>/dev/null | sort -k5 -h

# Największe katalogi
du -h --max-depth=3 / 2>/dev/null | sort -h | tail -30
```

**Krok 3: Trwałe rozwiązanie**
```bash
# Dodaj log rotation dla Docker
cat > /etc/docker/daemon.json << 'EOF'
{
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "10m",
    "max-file": "3"
  }
}
EOF
sudo systemctl restart docker
```

### Monitorowanie:
```bash
# Alert Prometheus
- alert: DiskSpaceLow
  expr: node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"} < 0.1
  for: 5m
```

---

## PROC-003: Kontener nie startuje

### Diagnoza:
```bash
# Sprawdź status
docker ps -a | grep [NAZWA]
docker logs [NAZWA] --tail 100

# Sprawdź eventy
docker events --since="1h" --filter container=[NAZWA]

# Inspect
docker inspect [NAZWA] | jq '.[0].State'
```

### Typowe problemy:

**Problem: Port zajęty**
```bash
# Znajdź co blokuje port
ss -tulpn | grep [PORT]
# Zwolnij lub zmień port w compose
```

**Problem: Volume permissions**
```bash
# Sprawdź właściciela
ls -la [VOLUME_PATH]
# Napraw
chown -R [UID]:[GID] [VOLUME_PATH]
```

**Problem: Out of memory**
```bash
# Sprawdź limity
docker stats --no-stream
# Zwiększ w compose lub zwolnij RAM
```

**Problem: Image nie istnieje**
```bash
docker pull [IMAGE]
docker-compose pull
```

### Restart sekwencja:
```bash
# 1. Zatrzymaj czysto
docker-compose down

# 2. Sprawdź volumes
docker volume ls

# 3. Uruchom z logami
docker-compose up -d
docker-compose logs -f
```

---

## PROC-004: Atak DDoS/Brute-force

### Symptomy:
- Wysokie CPU/sieć
- Dużo połączeń z jednego IP
- Fail2ban alerty
- Timeout usług

### Natychmiastowa reakcja:
```bash
# 1. Identyfikacja źródła
ss -an | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -rn | head -20

# 2. Sprawdź fail2ban
sudo fail2ban-client status sshd

# 3. Blokuj natychmiast najgorsze IP
sudo ufw deny from [IP_ADDRESS]
# lub
sudo iptables -A INPUT -s [IP_ADDRESS] -j DROP
```

### Eskalacja (dla poważnego DDoS):
```bash
# Włącz tryb ochronny
# 1. Ogranicz połączenia
sudo iptables -A INPUT -p tcp --syn -m limit --limit 1/s --limit-burst 3 -j ACCEPT
sudo iptables -A INPUT -p tcp --syn -j DROP

# 2. Włącz GeoIP blocking (jeśli skonfigurowane)
# 3. Kontakt z providerem - mogą mieć DDoS protection

# 4. Jako ostateczność - zamknij wszystko oprócz SSH
sudo ufw default deny incoming
sudo ufw allow 22/tcp
```

### Po ataku:
```bash
# Analiza logów
grep "Failed password" /var/log/auth.log | tail -100
cat /var/log/traefik/access.log | awk '{print $1}' | sort | uniq -c | sort -rn | head

# Dokumentacja
echo "[$(date)] DDoS/Brute-force attack from [IPs] - [AKCJE]" >> /var/log/incidents.log
```

---

## PROC-005: Wyciek danych / Breach

### ⚠️ KRYTYCZNE - DZIAŁAJ NATYCHMIAST

### Krok 1: IZOLACJA (0-5 min)
```bash
# Odetnij sieć zewnętrzną (zachowaj SSH!)
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT
sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Lub nuclear option - odłącz od sieci w panelu providera
```

### Krok 2: ZACHOWAJ DOWODY (5-15 min)
```bash
# Timestamp wszystkiego
date > /evidence/incident-start-$(date +%Y%m%d%H%M).txt

# Snapshot stanu systemu
ps aux > /evidence/processes.txt
ss -tulpn > /evidence/network.txt
docker ps -a > /evidence/containers.txt
last -100 > /evidence/logins.txt

# Kopiuj logi
cp -r /var/log/ /evidence/system-logs/
docker logs --tail 10000 [EACH_CONTAINER] > /evidence/docker-logs/

# Memory dump (jeśli możliwe)
# sudo dd if=/dev/mem of=/evidence/memory.dump bs=1M count=1024
```

### Krok 3: ANALIZA
```bash
# Kto się logował
last -20
cat /var/log/auth.log | grep -i accepted

# Jakie procesy działają
ps aux --forest

# Czy są podejrzane pliki
find / -mtime -1 -type f 2>/dev/null | head -100
find /tmp /var/tmp -type f -executable 2>/dev/null
```

### Krok 4: RAPORTOWANIE
```markdown
## Incident Report - {{DATE}}

**Czas wykrycia:** 
**Czas izolacji:**
**Zakres:**
**Potencjalnie naruszone dane:**
**Podjęte akcje:**
**Status:**
```

### Krok 5: RECOVERY
- NIGDY nie przywracaj starego stanu - może być zainfekowany
- Fresh install + restore from VERIFIED backup
- Zmień WSZYSTKIE hasła/klucze
- Audyt wszystkich kont

---

## PROC-006: Baza danych niedostępna

### Diagnoza:
```bash
# Sprawdź kontener
docker ps -a | grep postgres
docker logs postgres --tail 50

# Sprawdź zasoby
docker stats postgres --no-stream

# Test połączenia
docker exec -it postgres psql -U [USER] -c "SELECT 1"
```

### Typowe rozwiązania:

**Problem: Kontener crashed**
```bash
docker start postgres
docker logs -f postgres
```

**Problem: Corrupted data**
```bash
# STOP! Nie usuwaj danych!
# 1. Zrób backup tego co jest
docker cp postgres:/var/lib/postgresql/data /backup/postgres-corrupted-$(date +%Y%m%d)

# 2. Spróbuj recovery
docker exec -it postgres pg_resetwal -f /var/lib/postgresql/data
# lub przywróć z backupu
```

**Problem: Too many connections**
```bash
# Sprawdź połączenia
docker exec -it postgres psql -U [USER] -c "SELECT count(*) FROM pg_stat_activity"

# Zabij idle connections
docker exec -it postgres psql -U [USER] -c "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE state = 'idle' AND query_start < now() - interval '10 minutes'"
```

---

## PROC-007: Certyfikat SSL wygasł

### Diagnoza:
```bash
# Sprawdź datę wygaśnięcia
echo | openssl s_client -connect [DOMENA]:443 2>/dev/null | openssl x509 -noout -dates

# Sprawdź Traefik logs
docker logs traefik | grep -i cert
```

### Rozwiązanie (Let's Encrypt via Traefik):
```bash
# 1. Sprawdź konfigurację acme
cat traefik/traefik.yml | grep -A 20 certificatesResolvers

# 2. Wymuś odnowienie
docker restart traefik

# 3. Sprawdź
docker logs -f traefik | grep -i acme
```

### Manual renewal:
```bash
# Jeśli używasz certbot bezpośrednio
sudo certbot renew --force-renewal
sudo systemctl reload nginx  # lub traefik
```

---

## PROC-008: Out of Memory

### Natychmiastowa reakcja:
```bash
# Sprawdź stan
free -h
docker stats --no-stream

# Znajdź memory hog
ps aux --sort=-%mem | head -10
```

### Rozwiązanie:
```bash
# 1. Zatrzymaj największe kontenery tymczasowo
docker stop [MEMORY_HOG]

# 2. Wyczyść cache (bezpieczne)
sync; echo 3 > /proc/sys/vm/drop_caches

# 3. Dodaj/włącz swap (tymczasowo)
sudo fallocate -l 2G /swapfile
sudo chmod 600 /swapfile
sudo mkswap /swapfile
sudo swapon /swapfile

# 4. Ustaw limity w docker-compose
deploy:
  resources:
    limits:
      memory: 512M
```

---

## 📞 KONTAKTY ESKALACYJNE

| Poziom | Kontakt | Kiedy |
|--------|---------|-------|
| L1 | [AUTO-ALERT] | Zawsze |
| L2 | [ADMIN_EMAIL] | Gdy L1 nie wystarcza |
| L3 | [PROVIDER_SUPPORT] | Problemy z infrastrukturą |
| L4 | [SECURITY_TEAM] | Breach/Security incident |

---

## 📝 TEMPLATE LOGU INCYDENTU

```markdown
## Incident #{{ID}} - {{DATE}}

### Summary
- **Wykryto:** {{TIMESTAMP}}
- **Rozwiązano:** {{TIMESTAMP}}
- **Czas trwania:** {{DURATION}}
- **Severity:** 🟢/🟡/🔴/⚫
- **Procedura:** PROC-{{NUM}}

### Timeline
| Czas | Akcja | Rezultat |
|------|-------|----------|
| HH:MM | | |

### Root Cause
{{OPIS}}

### Resolution
{{OPIS}}

### Lessons Learned
{{OPIS}}

### Action Items
- [ ] {{AKCJA}}
```

---

*Ostatnia weryfikacja procedur: {{DATE}}*
*Następna weryfikacja: {{DATE + 90 dni}}*
