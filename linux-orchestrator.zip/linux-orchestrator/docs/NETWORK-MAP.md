# 🌐 NETWORK-MAP.md - Mapa Sieci i Portów

> **KOMPLETNY PRZEGLĄD KONFIGURACJI SIECIOWEJ**
> 
> Przed otwarciem portu SPRAWDŹ czy nie koliduje.
> Po otwarciu portu ZAWSZE zaktualizuj ten plik.

---

## 📊 Podsumowanie Portów

| Zakres | Przeznaczenie | Wykorzystane |
|--------|---------------|--------------|
| 1-1023 | System/Well-known | SSH (22), HTTP (80), HTTPS (443) |
| 1024-9999 | Aplikacje | - |
| 10000-19999 | Monitoring | - |
| 20000-29999 | Databases | - |
| 30000-39999 | Dev/Test | - |

---

## 🔥 FIREWALL STATUS

### UFW Rules (jeśli używane)
```bash
# Sprawdź aktualny status:
sudo ufw status verbose

# Oczekiwana konfiguracja:
Status: active
Logging: on (medium)
Default: deny (incoming), allow (outgoing), disabled (routed)

To                         Action      From
--                         ------      ----
22/tcp                     ALLOW       Anywhere        # SSH
80/tcp                     ALLOW       Anywhere        # HTTP
443/tcp                    ALLOW       Anywhere        # HTTPS
```

### iptables (jeśli używane)
```bash
# Sprawdź:
sudo iptables -L -n -v --line-numbers

# Zapisz backup:
sudo iptables-save > /backup/iptables-$(date +%Y%m%d).rules
```

---

## 📍 MAPA PORTÓW

### 🌍 PUBLICZNE (dostępne z internetu)

| Port | Protokół | Usługa | Kontener | Uwagi |
|------|----------|--------|----------|-------|
| 22 | TCP | SSH | HOST | Fail2ban aktywny |
| 80 | TCP | HTTP | traefik | Redirect → 443 |
| 443 | TCP | HTTPS | traefik | SSL termination |

### 🏠 WEWNĘTRZNE (localhost / VPN only)

| Port | Protokół | Usługa | Kontener | Uwagi |
|------|----------|--------|----------|-------|
| 8080 | TCP | Traefik Dashboard | traefik | NIE eksponuj! |
| 9090 | TCP | Prometheus | prometheus | Tylko monitoring network |
| 3000 | TCP | Grafana | grafana | Przez Traefik |
| 9443 | TCP | Portainer | portainer | Przez Traefik |
| 5432 | TCP | PostgreSQL | postgres | Tylko database network |
| 6379 | TCP | Redis | redis | Tylko database network |
| 9100 | TCP | Node Exporter | node-exporter | Tylko monitoring |
| 8081 | TCP | cAdvisor | cadvisor | Tylko monitoring |

### 🚫 ZAREZERWOWANE (nie używać)

| Port | Powód |
|------|-------|
| 25 | SMTP - często blokowany przez ISP |
| 3306 | MySQL - jeśli planujesz dodać |
| 27017 | MongoDB - jeśli planujesz dodać |
| 9200 | Elasticsearch - jeśli planujesz dodać |

---

## 🔗 SIECI DOCKER

```
┌─────────────────────────────────────────────────────────────────────┐
│                        DOCKER NETWORKS                               │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                    INTERNET                                  │    │
│  └──────────────────────────┬──────────────────────────────────┘    │
│                             │                                        │
│                             ▼                                        │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │              traefik-public (172.20.0.0/16)                 │    │
│  │                                                              │    │
│  │   ┌─────────┐  ┌─────────┐  ┌─────────┐  ┌─────────┐       │    │
│  │   │ Traefik │  │ Grafana │  │Portainer│  │  Apps   │       │    │
│  │   │ :80/443 │  │  :3000  │  │  :9443  │  │  :XXXX  │       │    │
│  │   └────┬────┘  └────┬────┘  └────┬────┘  └────┬────┘       │    │
│  └────────┼────────────┼────────────┼────────────┼─────────────┘    │
│           │            │            │            │                   │
│           ▼            ▼            ▼            ▼                   │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                 internal (172.21.0.0/16)                     │    │
│  │                                                              │    │
│  │   Komunikacja między usługami (nie eksponowana)             │    │
│  │                                                              │    │
│  └─────────────────────────────────────────────────────────────┘    │
│           │                                      │                   │
│           ▼                                      ▼                   │
│  ┌────────────────────┐              ┌────────────────────────┐     │
│  │  monitoring        │              │  database              │     │
│  │  (172.22.0.0/16)   │              │  (172.23.0.0/16)       │     │
│  │                    │              │                        │     │
│  │ ┌──────────────┐   │              │ ┌──────────────┐       │     │
│  │ │ Prometheus   │   │              │ │ PostgreSQL   │       │     │
│  │ │ Node-Export  │   │              │ │ Redis        │       │     │
│  │ │ cAdvisor     │   │              │ │ [inne DB]    │       │     │
│  │ └──────────────┘   │              │ └──────────────┘       │     │
│  └────────────────────┘              └────────────────────────┘     │
│                                                                      │
│  ┌─────────────────────────────────────────────────────────────┐    │
│  │                  security (172.24.0.0/16)                    │    │
│  │                                                              │    │
│  │   ┌──────────┐  ┌──────────┐  ┌──────────┐                  │    │
│  │   │ CrowdSec │  │ Authentik│  │ Vault    │                  │    │
│  │   └──────────┘  └──────────┘  └──────────┘                  │    │
│  └─────────────────────────────────────────────────────────────┘    │
│                                                                      │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 🔒 ZASADY BEZPIECZEŃSTWA SIECIOWEGO

### Hierarchia dostępu:

| Poziom | Dostęp | Przykład |
|--------|--------|----------|
| **PUBLIC** | Internet → Traefik → Usługa | WWW, API publiczne |
| **PROTECTED** | Internet → Traefik + Auth → Usługa | Grafana, Portainer |
| **INTERNAL** | Tylko sieci Docker | Prometheus, bazy danych |
| **HOST** | Tylko localhost | Debug, development |

### Wymagania przed otwarciem portu:

```markdown
## CHECKLIST - Otwarcie portu {{PORT}}

- [ ] Uzasadnienie biznesowe: _______________
- [ ] Czy można przez reverse proxy? TAK/NIE
- [ ] Jeśli NIE - dlaczego: _______________
- [ ] Rate limiting skonfigurowany? TAK/NIE
- [ ] Fail2ban rule dodany? TAK/NIE
- [ ] Monitoring health check? TAK/NIE
- [ ] SSL/TLS? TAK/NIE/N/A
- [ ] Authentication? TAK/NIE/N/A

Zatwierdził: _______________
Data: _______________
```

---

## 📋 DNS / DOMENY

| Domena | Cel | Proxy | Certyfikat |
|--------|-----|-------|------------|
| example.com | Main site | Traefik | Let's Encrypt |
| api.example.com | API | Traefik | Let's Encrypt |
| grafana.example.com | Monitoring | Traefik + Auth | Let's Encrypt |
| portainer.example.com | Docker UI | Traefik + Auth | Let's Encrypt |

### Traefik Labels Template:
```yaml
labels:
  - "traefik.enable=true"
  - "traefik.http.routers.${SERVICE}.rule=Host(`${DOMAIN}`)"
  - "traefik.http.routers.${SERVICE}.entrypoints=websecure"
  - "traefik.http.routers.${SERVICE}.tls.certresolver=letsencrypt"
  # Jeśli wymaga auth:
  - "traefik.http.routers.${SERVICE}.middlewares=authentik@docker"
```

---

## 🚨 PROCEDURA AWARYJNEGO ZAMKNIĘCIA

```bash
# NUCLEAR OPTION - zamknij wszystko oprócz SSH
sudo ufw default deny incoming
sudo ufw default allow outgoing
sudo ufw allow 22/tcp
sudo ufw --force enable

# Lub iptables:
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT ACCEPT
sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -A INPUT -p tcp --dport 22 -j ACCEPT
sudo iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
```

⚠️ **UWAGA:** To zablokuje WSZYSTKIE usługi! Używaj tylko w sytuacji krytycznej.

---

## 📊 MONITORING SIECI

### Polecenia diagnostyczne:
```bash
# Aktywne połączenia
ss -tulpn

# Ruch na interfejsie
iftop -i eth0

# Połączenia do konkretnego portu
ss -an | grep :443 | wc -l

# Docker network inspect
docker network ls
docker network inspect traefik-public
```

### Alerty Prometheus (przykład):
```yaml
groups:
  - name: network
    rules:
      - alert: HighNetworkConnections
        expr: node_netstat_Tcp_CurrEstab > 1000
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: "High number of TCP connections"
```

---

*Ostatnia aktualizacja: {{TIMESTAMP}}*
