# 📊 SYSTEM-STATE.md - Bieżący Stan Systemu

> Aktualizowany automatycznie i ręcznie.
> Źródło prawdy o stanie infrastruktury.

---

## 🖥️ Informacje o Systemie

| Pole | Wartość |
|------|---------|
| **Hostname** | {{HOSTNAME}} |
| **OS** | Ubuntu 24.04 LTS |
| **Kernel** | {{KERNEL}} |
| **IP Public** | {{PUBLIC_IP}} |
| **IP Private** | {{PRIVATE_IP}} |
| **Provider** | {{OVH/Hetzner/AWS/...}} |
| **Location** | {{DATACENTER}} |

---

## 📈 Zasoby

### CPU
| Metryka | Wartość |
|---------|---------|
| Model | {{CPU_MODEL}} |
| Cores | {{CORES}} |
| Load (1/5/15) | {{LOAD}} |

### RAM
| Metryka | Wartość |
|---------|---------|
| Total | {{RAM_TOTAL}} |
| Used | {{RAM_USED}} |
| Free | {{RAM_FREE}} |
| Available | {{RAM_AVAILABLE}} |

### Dysk
| Mount | Size | Used | Avail | Use% |
|-------|------|------|-------|------|
| / | {{SIZE}} | {{USED}} | {{AVAIL}} | {{PCT}} |
| /home | {{SIZE}} | {{USED}} | {{AVAIL}} | {{PCT}} |

---

## 🐳 Docker Status

### Podsumowanie
| Metryka | Ilość |
|---------|-------|
| Running | {{N}} |
| Stopped | {{N}} |
| Images | {{N}} |
| Volumes | {{N}} |
| Networks | {{N}} |

### Kontenery
| Nazwa | Status | CPU | RAM | Uptime |
|-------|--------|-----|-----|--------|
| {{NAME}} | 🟢/🔴 | {{CPU}}% | {{RAM}} | {{UPTIME}} |

*Szczegóły: → [DOCKER-REGISTRY.md](../docs/DOCKER-REGISTRY.md)*

---

## 🌐 Sieć

### Otwarte Porty (publiczne)
| Port | Usługa | Status |
|------|--------|--------|
| 22 | SSH | 🟢 |
| 80 | HTTP | 🟢 |
| 443 | HTTPS | 🟢 |

*Pełna mapa: → [NETWORK-MAP.md](../docs/NETWORK-MAP.md)*

### Firewall
```
Status: active
Default: deny (incoming), allow (outgoing)
Rules: {{N}}
```

### DNS
| Domena | Cel | Status |
|--------|-----|--------|
| {{DOMENA}} | {{IP}} | 🟢/🔴 |

---

## 🔒 Security Status

| Komponent | Status | Ostatni check |
|-----------|--------|---------------|
| UFW | 🟢 Active | {{TIMESTAMP}} |
| Fail2ban | 🟢 Active | {{TIMESTAMP}} |
| SSH Key-only | 🟢 Enabled | {{TIMESTAMP}} |
| Auto-updates | 🟢 Enabled | {{TIMESTAMP}} |

### Ostatnie bany (Fail2ban)
| IP | Jail | Czas | Status |
|----|------|------|--------|
| - | - | - | - |

---

## 📅 Maintenance Windows

| Zadanie | Harmonogram | Ostatnie | Następne |
|---------|-------------|----------|----------|
| System updates | Niedziela 3:00 | {{DATE}} | {{DATE}} |
| Docker cleanup | Codziennie 4:00 | {{DATE}} | {{DATE}} |
| Backup | Codziennie 2:00 | {{DATE}} | {{DATE}} |
| SSL renewal | Auto (Traefik) | {{DATE}} | {{DATE}} |
| Security audit | Miesięcznie | {{DATE}} | {{DATE}} |

---

## ⚠️ Aktywne Problemy

| ID | Opis | Severity | Owner | Status |
|----|------|----------|-------|--------|
| - | Brak aktywnych problemów | - | - | - |

*Szczegóły: → [ACTIVE-ISSUES.md](./ACTIVE-ISSUES.md)*

---

## 📋 Pending Tasks

| ID | Zadanie | Priorytet | Due |
|----|---------|-----------|-----|
| - | - | - | - |

*Szczegóły: → [PENDING-TASKS.md](./PENDING-TASKS.md)*

---

## 🔗 Quick Links

- **Dokumentacja:** `docs/`
- **Docker Registry:** `docs/DOCKER-REGISTRY.md`
- **Network Map:** `docs/NETWORK-MAP.md`
- **Security Policies:** `docs/SECURITY-POLICIES.md`
- **Emergency Runbook:** `docs/EMERGENCY-RUNBOOK.md`
- **Error Log:** `logs/errors/ERROR-LOG.md`

---

## 📊 Ostatnie zmiany

| Data | Zmiana | Agent |
|------|--------|-------|
| {{DATE}} | Initial setup | Claude Code |

---

*Ostatnia aktualizacja: {{TIMESTAMP}}*
*Źródło: Automatyczne + manualne*
