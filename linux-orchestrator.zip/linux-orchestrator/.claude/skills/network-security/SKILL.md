---
name: network-security
description: Procedury bezpieczeństwa sieciowego - firewall, porty, SSL
---

# 🔒 Network Security Skill

Gdy użytkownik prosi o operacje związane z siecią, bezpieczeństwem lub otwarciem portów.

## PRZED OTWARCIEM PORTU

### Obowiązkowa checklist:
```markdown
## Port Opening Request: {{PORT}}

- [ ] Uzasadnienie biznesowe: _______________
- [ ] Czy można przez reverse proxy? TAK/NIE
- [ ] Jeśli NIE przez proxy - dlaczego: _______________
- [ ] Jaka usługa używa tego portu: _______________
- [ ] Rate limiting skonfigurowany? TAK/NIE
- [ ] Fail2ban rule potrzebny? TAK/NIE
- [ ] SSL/TLS wymagany? TAK/NIE
- [ ] Authentication potrzebna? TAK/NIE
```

### Sprawdź przed otwarciem:
```bash
# Czy port jest już używany?
ss -tulpn | grep :<PORT>

# Aktualny stan firewall
sudo ufw status verbose

# Sprawdź dokumentację
cat docs/NETWORK-MAP.md | grep -A5 "<PORT>"
```

## PROCEDURA OTWIERANIA PORTU

### Preferowana metoda: Przez Traefik (reverse proxy)
```yaml
# NIE otwieraj portu bezpośrednio!
# Zamiast tego dodaj labels do kontenera:

labels:
  - "traefik.enable=true"
  - "traefik.http.routers.${SERVICE}.rule=Host(`${SUBDOMAIN}.${DOMAIN}`)"
  - "traefik.http.routers.${SERVICE}.entrypoints=websecure"
  - "traefik.http.routers.${SERVICE}.tls.certresolver=letsencrypt"
  # Jeśli wymaga auth:
  - "traefik.http.routers.${SERVICE}.middlewares=auth@docker"
```

### Jeśli MUSI być bezpośrednio (tylko jako wyjątek):
```bash
# 1. Backup aktualnej konfiguracji
sudo iptables-save > /backup/iptables-$(date +%Y%m%d-%H%M).rules

# 2. Otwórz port
sudo ufw allow <PORT>/tcp comment '<USŁUGA> - <UZASADNIENIE>'

# 3. Dodaj rate limiting jeśli to usługa publiczna
sudo ufw limit <PORT>/tcp comment '<USŁUGA> rate limited'

# 4. OBOWIĄZKOWO zaktualizuj dokumentację
echo "| <PORT> | TCP | <USŁUGA> | <KONTENER> | <UWAGI> |" >> docs/NETWORK-MAP.md
```

## DIAGNOSTYKA SIECIOWA

### Sprawdzenie połączeń:
```bash
# Wszystkie nasłuchujące porty
ss -tulpn

# Aktywne połączenia
ss -an | head -50

# Połączenia per IP
ss -an | awk '{print $5}' | cut -d: -f1 | sort | uniq -c | sort -rn | head -20

# Ruch na konkretnym porcie
ss -an | grep :<PORT> | wc -l
```

### Sprawdzenie firewall:
```bash
# UFW status
sudo ufw status numbered

# iptables (bardziej szczegółowo)
sudo iptables -L -n -v --line-numbers
sudo iptables -L -n -v -t nat  # dla NAT/forwarding
```

### Test połączenia:
```bash
# Z serwera
curl -I http://localhost:<PORT>

# Z zewnątrz (użyj innego hosta)
curl -I https://<DOMENA>
nc -zv <IP> <PORT>
```

## FAIL2BAN

### Dodanie nowego jail:
```ini
# /etc/fail2ban/jail.d/<usługa>.conf

[<nazwa>]
enabled = true
port = <PORT>
filter = <nazwa>
logpath = <ścieżka_do_logów>
maxretry = 5
bantime = 1h
findtime = 10m
```

### Custom filter:
```ini
# /etc/fail2ban/filter.d/<nazwa>.conf

[Definition]
failregex = ^.*authentication failure.*from <HOST>.*$
            ^.*Failed password.*from <HOST>.*$
ignoreregex =
```

### Weryfikacja:
```bash
# Test regex
sudo fail2ban-regex /var/log/<log> /etc/fail2ban/filter.d/<nazwa>.conf

# Status
sudo fail2ban-client status <nazwa>

# Odbanuj IP (jeśli trzeba)
sudo fail2ban-client set <jail> unbanip <IP>
```

## SSL/TLS

### Sprawdzenie certyfikatu:
```bash
# Data wygaśnięcia
echo | openssl s_client -connect <DOMENA>:443 2>/dev/null | openssl x509 -noout -dates

# Pełne info
echo | openssl s_client -connect <DOMENA>:443 2>/dev/null | openssl x509 -noout -text

# Test SSL quality
# Użyj: https://www.ssllabs.com/ssltest/
```

### Wymuszenie odnowienia (Let's Encrypt via Traefik):
```bash
# Restart Traefik wymusza sprawdzenie certyfikatów
docker restart traefik

# Sprawdź logi
docker logs traefik 2>&1 | grep -i "acme\|cert\|ssl"
```

## BLOKOWANIE IP

### Tymczasowe (do restartu):
```bash
sudo iptables -A INPUT -s <IP> -j DROP
```

### Permanentne (UFW):
```bash
sudo ufw deny from <IP> comment 'Blocked: <POWÓD> - <DATA>'
```

### Blokowanie subnet:
```bash
sudo ufw deny from <IP>/24 comment 'Blocked subnet: <POWÓD>'
```

### Lista zablokowanych:
```bash
# UFW
sudo ufw status | grep DENY

# Fail2ban
sudo fail2ban-client status --all
```

## DOKUMENTACJA WYMAGANA

### Po każdej zmianie sieciowej:
1. **NETWORK-MAP.md** - aktualizuj porty i diagramy
2. **logs/commands/** - loguj polecenia
3. **SECURITY-POLICIES.md** - jeśli nowa polityka

### Format wpisu w logu:
```markdown
## [$(date)] Network Change

### Typ zmiany:
- [ ] Otwarcie portu
- [ ] Zamknięcie portu  
- [ ] Nowa reguła firewall
- [ ] Blokada IP
- [ ] Zmiana SSL

### Szczegóły:
- Port/IP: 
- Usługa:
- Uzasadnienie:

### Podjęte akcje:
1. ...
2. ...

### Weryfikacja:
- [ ] Port działa poprawnie
- [ ] Dokumentacja zaktualizowana
- [ ] Fail2ban skonfigurowany (jeśli dotyczy)
```

## 🚫 ZABRONIONE

| Akcja | Powód |
|-------|-------|
| `ufw disable` | Wyłącza cały firewall |
| `iptables -F` bez backupu | Usuwa wszystkie reguły |
| Port 0.0.0.0 bez auth | Ekspozycja na świat |
| SSH na innym porcie bez testowania | Zablokujesz się |
| Wyłączenie fail2ban | Brak ochrony przed brute-force |
