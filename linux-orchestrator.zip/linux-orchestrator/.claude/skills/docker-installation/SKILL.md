---
name: docker-installation
description: Procedura instalacji nowych kontenerów Docker z pełną dokumentacją
---

# 🐳 Docker Installation Skill

Gdy użytkownik prosi o instalację usługi/kontenera Docker, ZAWSZE wykonaj tę procedurę:

## PRZED INSTALACJĄ

### Krok 1: Sprawdź czy już istnieje
```bash
# Sprawdź działające kontenery
docker ps -a | grep -i "<nazwa_usługi>"

# Sprawdź obrazy
docker images | grep -i "<nazwa_usługi>"

# Sprawdź dokumentację
cat docs/DOCKER-REGISTRY.md | grep -i "<nazwa_usługi>"
```

### Krok 2: Sprawdź dostępność zasobów
```bash
# Miejsce na dysku
df -h

# RAM
free -h

# Porty
ss -tulpn | grep ":<planowany_port>"
```

### Krok 3: Sprawdź czy istnieje oficjalny obraz
```bash
# Docker Hub
docker search <nazwa> --limit 5

# Lub sprawdź na ghcr.io / quay.io
```

## INSTALACJA

### Standardowy docker-compose.yml
```yaml
version: "3.8"

services:
  <nazwa>:
    container_name: <nazwa>
    image: <obraz>:<tag>
    restart: unless-stopped
    
    # Security
    user: "1000:1000"  # jeśli możliwe
    security_opt:
      - no-new-privileges:true
    cap_drop:
      - ALL
    
    # Resources
    deploy:
      resources:
        limits:
          memory: 512M
          cpus: '1.0'
    
    # Network
    networks:
      - internal
    # ports:  # TYLKO jeśli konieczne
    #   - "127.0.0.1:PORT:PORT"
    
    # Storage
    volumes:
      - <nazwa>_data:/data
    
    # Health
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    
    # Labels
    labels:
      - "managed-by=claude-orchestrator"
      - "installed-date=${INSTALL_DATE}"
      - "purpose=<opis>"
    
    # Logging
    logging:
      driver: "json-file"
      options:
        max-size: "10m"
        max-file: "3"

networks:
  internal:
    external: true

volumes:
  <nazwa>_data:
```

### Lokalizacja pliku
```
infrastructure/docker-compose/<nazwa>/docker-compose.yml
```

## PO INSTALACJI

### Krok 1: Weryfikacja
```bash
# Sprawdź status
docker ps | grep <nazwa>

# Sprawdź logi
docker logs <nazwa> --tail 50

# Test health (jeśli dostępny)
docker inspect <nazwa> | jq '.[0].State.Health'
```

### Krok 2: OBOWIĄZKOWA DOKUMENTACJA

#### Zaktualizuj docs/DOCKER-REGISTRY.md:
```markdown
### 📦 <Nazwa Usługi>
\`\`\`yaml
container_name: <nazwa>
image: <obraz>:<tag>
status: 🟢 RUNNING
installed: <DATA>
purpose: <OPIS CO ROBI>

ports:
  - "<PORTY>"

volumes:
  - <VOLUMES>

networks:
  - <SIECI>

dependencies:
  - <ZALEŻNOŚCI>

notes: |
  <UWAGI>
  
maintenance:
  last_update: <DATA>
  next_review: <DATA + 30 dni>
\`\`\`
```

#### Zaktualizuj docs/NETWORK-MAP.md (jeśli nowe porty)

#### Dodaj wpis do logu:
```bash
echo "## $(date '+%Y-%m-%d %H:%M:%S')" >> logs/docker-changes/$(date +%Y-%m-%d).md
echo "### Instalacja: <nazwa>" >> logs/docker-changes/$(date +%Y-%m-%d).md
echo "- **Obraz:** <obraz>:<tag>" >> logs/docker-changes/$(date +%Y-%m-%d).md
echo "- **Porty:** <porty>" >> logs/docker-changes/$(date +%Y-%m-%d).md
echo "- **Cel:** <opis>" >> logs/docker-changes/$(date +%Y-%m-%d).md
echo "" >> logs/docker-changes/$(date +%Y-%m-%d).md
```

## PRZYKŁAD KOMPLETNY

```bash
# Użytkownik: "Zainstaluj Grafana"

# 1. Sprawdzenie
docker ps -a | grep -i grafana
# Brak wyników

cat docs/DOCKER-REGISTRY.md | grep -i grafana
# status: ⚫ NOT INSTALLED

# 2. Instalacja
mkdir -p infrastructure/docker-compose/grafana
cd infrastructure/docker-compose/grafana

# 3. Tworzenie compose (patrz wyżej)

# 4. Uruchomienie
docker-compose up -d
docker logs -f grafana

# 5. Dokumentacja
# - Update DOCKER-REGISTRY.md
# - Update NETWORK-MAP.md (port 3000)
# - Log do docker-changes/
```

## ZŁOTE ZASADY

1. **NIGDY nie instaluj bez sprawdzenia czy już istnieje**
2. **ZAWSZE używaj named networks, nie host**
3. **ZAWSZE ustaw restart policy**
4. **ZAWSZE dokumentuj w DOCKER-REGISTRY.md**
5. **ZAWSZE loguj zmiany**
6. **PREFERUJ instalację przez reverse proxy zamiast bezpośredniej ekspozycji portów**
