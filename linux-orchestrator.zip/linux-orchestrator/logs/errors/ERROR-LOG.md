# 🚨 ERROR-LOG.md - Log Błędów

> Każdy błąd, problem, nieoczekiwane zachowanie MUSI być tutaj zapisane.
> To jest "pamięć instytucjonalna" problemów systemu.

---

## 📊 Statystyki

| Okres | 🔴 Critical | 🟠 High | 🟡 Medium | 🟢 Low | ✅ Resolved |
|-------|-------------|---------|-----------|--------|-------------|
| Ten tydzień | 0 | 0 | 0 | 0 | 0 |
| Poprzedni tydzień | 0 | 0 | 0 | 0 | 0 |
| Ten miesiąc | 0 | 0 | 0 | 0 | 0 |

---

## 📋 Format Wpisu

```markdown
## ERROR-{{YYYY-MM-DD}}-{{N}}

**Timestamp:** {{DATETIME}}
**Agent:** Claude Code
**Severity:** 🔴 CRITICAL | 🟠 HIGH | 🟡 MEDIUM | 🟢 LOW
**Status:** 🔄 OPEN | ✅ RESOLVED | 🚫 WONT_FIX

### Opis
{{Co się stało}}

### Kontekst
- **Kontener:** {{CONTAINER_NAME}}
- **Operacja:** {{CO_ROBIŁEŚ}}
- **Polecenie:** `{{COMMAND}}`

### Logi / Stack Trace
\`\`\`
{{LOGS}}
\`\`\`

### Root Cause
{{Po analizie - dlaczego to się stało}}

### Rozwiązanie
{{Jak naprawiono / plan naprawy}}

### Lessons Learned
{{Co możemy zrobić żeby to się nie powtórzyło}}

### Related
- Procedura: PROC-{{NUM}} (jeśli użyta)
- Commit: {{HASH}} (jeśli fix)
```

---

## 🔴 CRITICAL (Wymagają natychmiastowej akcji)

*Brak aktywnych*

---

## 🟠 HIGH

*Brak aktywnych*

---

## 🟡 MEDIUM

*Brak aktywnych*

---

## 🟢 LOW

*Brak aktywnych*

---

## ✅ RESOLVED (Ostatnie 30 dni)

*Brak rozwiązanych problemów*

---

## 📈 Trending Issues

| Problem | Częstotliwość | Ostatni | Status |
|---------|---------------|---------|--------|
| - | - | - | - |

---

*Ostatnia aktualizacja: {{TIMESTAMP}}*
